(function($) {
    "use strict"

    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });



})(jQuery);